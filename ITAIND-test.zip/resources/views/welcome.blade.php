@extends('layouts.app')
@section('content')
<div class="container">
    <div class="jumbotron">
        <h1 class="display-4">Home Page</h1>
        <p class="lead">Bloging System</p>
        <hr class="my-4">
    </div>
</div>
@endsection
