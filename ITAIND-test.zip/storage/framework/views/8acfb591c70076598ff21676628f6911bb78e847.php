<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5>Add Post Details</h5>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('posts.update', $post->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input id="title" class="form-control" type="text" value="<?php echo e($post->title); ?>" name="title" placeholder="Enter Name">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="image">Image</label>
                            <input id="image" class="form-control" type="file" value="" name="image" placeholder="Enter Name">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                 <div class="form-group">
                                     <label for="category_id">Select Category</label>
                                     <select name="category_id" id="category_id" class="form-control" >
                                         <option value="" <?php echo e(($post->category_id == null) ? 'selected' : ''); ?>>Select</option>
                                         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($item->id); ?>" <?php echo e(( $post->category_id == $item->id) ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                 </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="status">Select Status</label>
                                    <select name="status" id="status" class="form-control" >
                                        <option value="" <?php echo e(($post->status == '') ? 'selected' : ''); ?>>Select</option>
                                        <option value="New" <?php echo e(($post->status == 'New') ? 'selected' : ''); ?>>New</option>
                                        <option value="Draft" <?php echo e(($post->status == 'Draft') ? 'selected' : ''); ?>>Draft</option>
                                        <option value="Published" <?php echo e(($post->status == 'Draft') ? 'selected' : ''); ?>>Published</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea id="description" name="description"><?php echo $post->description; ?></textarea>

                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    CKEDITOR.replace( 'description' );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teckborn-test\resources\views/posts/edit.blade.php ENDPATH**/ ?>