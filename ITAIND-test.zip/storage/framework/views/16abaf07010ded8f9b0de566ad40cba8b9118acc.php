<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <?php if(!auth()->user()->is_author): ?>

                    <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-primary float-right">Add New</a>
                    <?php endif; ?>
                    <h5>Articles : <?php echo e($articles->total()); ?></h5>
                </div>

                <div class="card-body">
                    <div class="mb-3">

                        <form class="form-inline" method="get" action="/search-post">
                            <div class="form-group">
                                <label for="search">Search by Name</label>
                                <input id="search" class="form-control" type="text" name="search" placeholder="type editor name">
                            </div>

                            <button type="submit" class="btn btn-primary">Search</button>
                        </form>
                    </div>
                    <?php
                        $x = 1;
                    ?>
                    <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th>Sr. No</th>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Tags</th>
                                <th>Created By</th>
                                <?php if(!auth()->user()->is_author): ?>
                                <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($x++); ?></td>
                                <td>
                                    <img src="<?php echo e(Storage::url($article->image)); ?>" alt="" width="50px">
                                </td>
                                <td><a href="<?php echo e(route('articles.show', $article->id)); ?>"><?php echo e(Str::limit($article->title, 50, '...')); ?></a></td>

                                <td>
                                    <?php $__currentLoopData = explode(',', $article->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-primary"><?php echo e($tag); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($article->owner->name); ?></td>
                                <td>
                                    <?php if(auth()->user()->id == $article->created_by): ?>
                                    <a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="btn btn-info btn-sm">Edit</a>
                                    <a href="<?php echo e(route('article.delete', $article->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="float-right">
                        <?php echo e($articles->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teckborn-test\resources\views/articles/index.blade.php ENDPATH**/ ?>