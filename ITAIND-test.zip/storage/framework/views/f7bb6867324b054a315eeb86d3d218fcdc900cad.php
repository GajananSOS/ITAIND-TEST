<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5>Add Article Details</h5>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('articles.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input id="title" class="form-control" type="text" value="<?php echo e(old('title')); ?>" name="title" placeholder="Enter Name">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="tags">Tags</label>
                            <input id="tags" class="form-control" type="text" value="<?php echo e(old('tags')); ?>" name="tags" placeholder="comma saperated tags">
                            <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="status">Select Status</label>
                                    <select name="status" id="status" class="form-control" >
                                        <option value="" <?php echo e((old('status') == '') ? 'selected' : ''); ?>>Select</option>
                                        <option value="New" <?php echo e((old('status') == 'New') ? 'selected' : ''); ?>>New</option>
                                        <option value="Draft" <?php echo e((old('status') == 'Draft') ? 'selected' : ''); ?>>Draft</option>
                                        <option value="Published" <?php echo e((old('status') == 'Published') ? 'selected' : ''); ?>>Published</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea id="description" name="description"><?php echo e(old('description')); ?></textarea>

                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    CKEDITOR.replace( 'description' );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teckborn-test\resources\views/articles/create.blade.php ENDPATH**/ ?>