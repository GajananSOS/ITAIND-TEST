<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary float-right">Add New</a>
                    <h5>Posts : <?php echo e($posts->total()); ?></h5>
                </div>

                <div class="card-body">
                    <div class="mb-3">

                        <form class="form-inline" method="get" action="/search-post">
                            <div class="form-group">
                                <label for="search">Search by Name</label>
                                <input id="search" class="form-control" type="text" name="search" placeholder="type editor name">
                            </div>

                            <button type="submit" class="btn btn-primary">Search</button>
                        </form>
                    </div>
                    <?php
                        $x = 1;
                    ?>
                    <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th>Sr. No</th>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Created By</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($x++); ?></td>
                                <td>
                                    <img src="<?php echo e(Storage::url($post->image)); ?>" alt="" width="50px">
                                </td>
                                <td><?php echo e($post->title); ?></td>
                                <td><?php echo e($post->category->name ?? '--'); ?></td>
                                <td><?php echo $post->description; ?></td>
                                <td><?php echo e($post->status); ?></td>
                                <td><?php echo e($post->owner->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-info btn-sm">Edit</a>

                                    <a href="<?php echo e(route('posts.delete', $post->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="float-right">
                        <?php echo e($posts->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teckborn-test\resources\views/posts/index.blade.php ENDPATH**/ ?>