<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="<?php echo e((Auth::user()->is_author) ? 'col-md-8' : 'col-md-9 mx-auto'); ?>">
            <div class="card">
                <img class="card-img-top" src="<?php echo e(Storage::url($article->image)); ?>" alt="Card image cap">
                <div class="card-header" >
                    
                    <h5><?php echo e($article->title); ?></h5>
                </div>
                <div class="card-body">
                    <h5>Tags: </h5>
                    <?php $__currentLoopData = explode(',', $article->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-primary"><?php echo e($tag); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-right">
                        <p><?php echo e($article->owner->name); ?></p>
                        <i><?php echo e($article->created_at); ?></i>
                    </div>
                    <div class="content py-3">
                        <?php echo $article->description; ?>

                    </div>
                    <hr>
                    <div class="comment-block">
                        <div class="comments">
                            <h5>Comments : <?php echo e(count($article->comments)); ?></h5>
                            <?php $__empty_1 = true; $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <ul class="list-unstyled">
                                <li class="media">
                                <img src="/img/user.png" width="50px" alt="">
                                <div class="media-body ml-3">
                                      <h5 class="mt-0 mb-1"><?php echo e($comment->commented_by->name); ?> <i><?php echo e(\Carbon\Carbon::parse($comment->created_at)->diffForHumans()); ?></i> </h5>
                                    <?php echo e($comment->comment); ?>

                                  </div>
                                </li>

                              </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                Be a first person to comment
                            <?php endif; ?>
                        </div>
                        <hr>
                        <form action="/comment/store" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="comment">Comment</label>
                                <textarea id="comment" class="form-control" name="comment" rows="3"></textarea>
                            </div>
                            <input type="hidden" name="article_id" value="<?php echo e($article->id); ?>">
                            <button class="btn btn-primary" type="submit">Comment</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
        <?php if(Auth::user()->is_author): ?>

        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Upload Image</h5>

                    <form action="/upload/article-image/<?php echo e($article->id); ?>" method="post" enctype="multipart/form-data">
                           <?php echo csrf_field(); ?>
                           <div class="custom-file mb-3">
                               <input id="image" class="custom-file-input" type="file" name="image">
                               <label for="image" class="custom-file-label">Image</label>
                           </div>
                           <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <small class="form-text text-dager"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                           <button class="btn btn-primary" type="submit">Upload</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teckborn-test\resources\views/articles/show.blade.php ENDPATH**/ ?>