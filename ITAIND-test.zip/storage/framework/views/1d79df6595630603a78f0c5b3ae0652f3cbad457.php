<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary float-right">Add New</a>
                    <h5>Categories</h5>
                </div>

                <div class="card-body">
                    <?php
                        $x = 1;
                    ?>
                    <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th>Sr. No</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($x++); ?></td>
                                <td><?php echo e($category->name); ?></td>
                                <td><?php echo e($category->description); ?></td>
                                <td>
                                    <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-info btn-sm">Edit</a>

                                    <a href="<?php echo e(route('categories.delete', $category->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teckborn-test\resources\views/categories/index.blade.php ENDPATH**/ ?>